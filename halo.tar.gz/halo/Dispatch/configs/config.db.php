<?php
/**
 +-----------------
 * mysql数据库配置 
 +-----------------
 */
define('DB_HOST', '127.0.0.1');         // host
define('DB_PORT', '3306');              // 端口号
define('DB_USER', 'halo');              // 登录用户
define('DB_PASS', '295012469');         // 登录密码
define('DB_LIBR', 'halo');              // 默认操作的数据库
define('DB_PCONNECT', true);            // 是否持久连接
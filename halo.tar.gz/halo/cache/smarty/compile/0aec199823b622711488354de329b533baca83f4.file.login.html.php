<?php /* Smarty version Smarty-3.0.6, created on 2012-10-16 11:21:30
         compiled from "/data/developer/wangwei/myspace/webFrame/Code/template/html5/login.html" */ ?>
<?php /*%%SmartyHeaderCode:1600819931507cd2bab59eb9-57536496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0aec199823b622711488354de329b533baca83f4' => 
    array (
      0 => '/data/developer/wangwei/myspace/webFrame/Code/template/html5/login.html',
      1 => 1350357680,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1600819931507cd2bab59eb9-57536496',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>登陆</title>
        <style>
            #body_login{
                background: #CEDFF5;
            }
        
            .div_login {
                border-radius: 39px 39px 28px 28px;
                box-shadow: 1px 9px 66px #5166CC inset;
                height: 151px;
                margin: 118px auto;
                width: 369px;
            }
            
            #login_from{
                width: 300px;
                height:80px;
                border-style: double; 
                border-color: #A6FFFF;
                margin-top:2cm;
                 margin-left:2cm;
                 margin-right:2cm;
                 margin-bottom:2cm;
            }
        </style>
</head>
    <body id="body_login">
    <div class="div_login"> 
        <div id="login_from">
            
        </div>
    </div>
</body>
</html>
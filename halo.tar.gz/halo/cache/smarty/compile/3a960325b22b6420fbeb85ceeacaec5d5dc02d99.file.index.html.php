<?php /* Smarty version Smarty-3.0.6, created on 2012-11-07 15:41:22
         compiled from "/data/developer/wangwei/myspace/webFrame/Code/template/html5/index.html" */ ?>
<?php /*%%SmartyHeaderCode:1894414084509a10a2960bd1-94975554%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a960325b22b6420fbeb85ceeacaec5d5dc02d99' => 
    array (
      0 => '/data/developer/wangwei/myspace/webFrame/Code/template/html5/index.html',
      1 => 1352274059,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1894414084509a10a2960bd1-94975554',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>时间的故事</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css" type="text/css" media="all">


</head>

<body class = "indexBody">

<?php echo @CSS_PATH;?>

</body>
</html>
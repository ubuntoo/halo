<?php /* Smarty version Smarty-3.0.6, created on 2012-08-03 10:34:44
         compiled from "/data/developer/wangwei/myspace/webFrame/Code/template/html5/error.html" */ ?>
<?php /*%%SmartyHeaderCode:1733379312501b38c442cc52-40486314%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '34141294948ca24a05607d50c0467c6c98f48d45' => 
    array (
      0 => '/data/developer/wangwei/myspace/webFrame/Code/template/html5/error.html',
      1 => 1343038379,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1733379312501b38c442cc52-40486314',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>错误提示</title>
</head>
<body>
   
</body>
</html>
<?php /* Smarty version Smarty-3.0.6, created on 2012-05-05 18:44:48
         compiled from "F:\wamp\www\webFrame\webFrame\Code\template\html5\index.html" */ ?>
<?php /*%%SmartyHeaderCode:242934fa504a086ee61-56757997%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '44c082559655c4422d245b5b408d492cdc92dccc' => 
    array (
      0 => 'F:\\wamp\\www\\webFrame\\webFrame\\Code\\template\\html5\\index.html',
      1 => 1333695132,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '242934fa504a086ee61-56757997',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html>
<head>  <!--头文件-->
<!--标题-->
<title>主页-home</title>
<!--页面元信息 utf8格式-->
<meta charset="utf-8">
<!--定义连接文档间关系-->
<link rel="stylesheet" href="<?php echo @CSS;?>
/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo @CSS;?>
/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo @CSS;?>
/style.css" type="text/css" media="all">
<!--引入脚本-->
<script type="text/javascript" src="<?php echo @JS;?>
/jquery-1.4.2.js" ></script>
<script type="text/javascript" src="<?php echo @JS;?>
/cufon-yui.js"></script>
<!--
<script type="text/javascript" src="js/cufon-replace.js"></script>	
-->
<script type="text/javascript" src="<?php echo @JS;?>
/Myriad_Pro_300.font.js"></script>
<!--[if lt IE 9]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
	<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
</head>
 <!--主体-->
<body id="page1">

<div class="body3"></div>

<div class="body1">
	<div class="main">
		<header>
			<div id="logo_box">
				<h1><a href="#" id="logo">美杜莎<span>第二梦</span></a></h1>
			</div>
			
			<nav>
				<ul id="menu">
					<li id="menu_active"><a href="index.html">主页</a></li>
					<li><a href="About.html">空间</a></li>
					<li><a href="Projects.html">图片</a></li>
					<li><a href="Contacts.html">视频</a></li>
					<li class="bg_none"><a href="SiteMap.html">游戏</a></li>
				</ul>
			</nav>
			
			<div class="wrapper">
				<div class="text1">傻逼天天有</div>
				<div class="text2">今天比较多</div>
				<ul id="icons">
					<li><span>分享</span></li>
					<li><a href="#"><img src="<?php echo @IMAGES;?>
/icon1.jpg" alt=""></a></li>
					<li><a href="#"><img src="<?php echo @IMAGES;?>
/icon2.jpg" alt=""></a></li>
					<li><a href="#"><img src="<?php echo @IMAGES;?>
/icon3.jpg" alt=""></a></li>
				</ul>
			</div>
		
		</header>


<!-- / header -->
	</div>
</div>


<div class="body2">
	<div class="main">
<!-- content -->
		<section id="content">
			<div class="marg_top wrapper">
				<article class="col1">
					<div class="box1_out">
						<div class="box1">
							<h2>内容标题1</h2>
							<p class="pad_bot1">
								内容1
							</p>
							<a href="#" class="button"><span><span>内容-按钮1</span></span></a>
							<img src="<?php echo @IMAGES;?>
/img1.png" class="img" alt="">
						</div>
					</div>
					<div class="box1_bot"><div class="box1_bot_left"><div class="box1_bot_right"></div></div></div>
				</article>
				
				<article class="col1 pad_left1">
					<div class="box1_out">
						<div class="box1">
							<h2>内容标题2</h2>
							<p class="pad_bot1">
								内容2
							</p>
							<a href="#" class="button"><span><span>内容-按钮2</span></span></a>
							<img src="<?php echo @IMAGES;?>
/img2.png" class="img" alt="">
						</div>
					</div>
					<div class="box1_bot"><div class="box1_bot_left"><div class="box1_bot_right"></div></div></div>
				</article>
				
				<article class="col1 pad_left1">
					<div class="box1_out">
						<div class="box1">
							<h2>内容标题3</h2>
							<p class="pad_bot1">
								内容3
							</p>
							<a href="#" class="button"><span><span>内容-按钮3</span></span></a>
							<img src="<?php echo @IMAGES;?>
/img3.png" class="img" alt="">
						</div>
					</div>
					<div class="box1_bot"><div class="box1_bot_left"><div class="box1_bot_right"></div></div></div>
				</article>
				
				
			</div>
			
			<div class="wrapper marg_top2">
				<article class="col1">
					<div class="box2">
						<div class="pad">
							<h2>模块</h2>
							<div class="wrapper pad_bot1">
								<figure><img src="<?php echo @IMAGES;?>
/page1_img1.jpg" alt="" class="left marg_right1"></figure>
								<span class="color1">模块1</span><br>
								模块内容1<a href="#">模块-连接1</a>
							</div>
							<div class="wrapper pad_bot1">
								<figure><img src="<?php echo @IMAGES;?>
/page1_img2.jpg" alt="" class="left marg_right1"></figure>
								<span class="color1">模块2</span><br>
							模块内容2 <a href="#">模块-连接2</a>
							</div>
							<div class="wrapper pad_bot1">
								<figure><img src="<?php echo @IMAGES;?>
/page1_img3.jpg" alt="" class="left marg_right1"></figure>
								<span class="color1">模块3</span><br>
							模块内容3<a href="#">模块-连接3</a>
							</div>
						</div>
					</div>
				</article>
				<article class="col2 pad_left1">
					<div class="pad">
						<h2>板块1</h2>
						<p><strong>XX</strong> XXX </p>
						<p class="under">XX <a href="Home.html">XX</a>, <a href="About.html">XX</a>, <a href="Projects.html">XX</a> (with <a href="Project.html">XX</a>), <a href="Contacts.html">XX</a> XX <a href="SiteMap.html">XX</a>.</p>
						<div class="wrapper">
							<ul class="list1 cols">
								<li><a href="#">连接1</a></li>
								<li><a href="#">连接2</a></li>
								<li><a href="#">连接3</a></li>
							</ul>
							<ul class="list1 cols pad_left1">
								<li><a href="#">连接4</a></li>
								<li><a href="#">连接5</a></li>
								<li><a href="#">连接6</a></li>
							</ul>
						</div>
					</div>
				</article>
			</div>
		</section>
<!-- / content -->
	</div>
</div>
<div class="main">
<!-- footer -->
	<footer>
		<div class="wrapper">
			<article class="col1">
				<div class="pad">
					<h2>aaa</h2>
					<p>aaa</p>
					<ul class="list1">
						<li><a href="#">a</a></li>
						<li><a href="#">b</a></li>
					</ul>
				</div>
			</article>
			<article class="col2 pad_left1">
				<div class="pad">
					<div class="wrapper">
						<article class="cols">
							<h2>A</h2>
							<form id="form_1" action="" method="post">
								<div>
									<div class="bg"><input class="input" type="text" value="Enter email here" onblur="if(this.value=='') this.value='Enter email here'" onFocus="if(this.value =='Enter email here' ) this.value=''" /></div>
									<a href="#" class="submit" onClick="document.getElementById('form_1').submit()"><span><span>按钮</span></span></a>
									<a href="#">b</a>
								</div>
							</form>
						</article>
						<article class="cols pad_left1">
							<h2>b</h2>
							<form id="form_2" action="" method="post">
								<div>
									<div class="bg left"><input class="input input1" type="text" value="Enter user ID here"	onblur="if(this.value=='') this.value='Enter user ID here'" onFocus="if(this.value =='Enter user ID here' ) this.value=''" /></div>
									<div class="bg right"><input class="input input2" type="password" value="••••••••••" onblur="if(this.value=='') this.value='••••••••••'" onFocus="if(this.value =='••••••••••' ) this.value=''"	 /></div>
									<a href="#" class="submit" onClick="document.getElementById('form_2').submit()"><span><span>D</span></span></a>
									<a href="#">B</a> &nbsp;	<a href="#">C</a>
								</div>
							</form>
						</article>
					</div>
				</div>	
			</article>
		</div>
		<div class="under2"></div>
		<div class="wrapper font_size">
			<div class="pad">
				<a href="http://www.templatemonster.com/" target="_blank">1</a> 2<br>
				<a href="http://www.templates.com/product/3d-models/" target="_blank">3</a> 4
			</div>
		</div>
	</footer>
<!-- / footer -->
</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
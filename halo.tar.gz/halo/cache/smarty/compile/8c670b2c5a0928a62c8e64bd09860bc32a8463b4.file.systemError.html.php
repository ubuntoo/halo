<?php /* Smarty version Smarty-3.0.6, created on 2012-08-03 11:25:53
         compiled from "/data/developer/wangwei/myspace/webFrame/Code/template/html5/systemError.html" */ ?>
<?php /*%%SmartyHeaderCode:1461455922501b44c1cbbad0-23999530%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c670b2c5a0928a62c8e64bd09860bc32a8463b4' => 
    array (
      0 => '/data/developer/wangwei/myspace/webFrame/Code/template/html5/systemError.html',
      1 => 1343964351,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1461455922501b44c1cbbad0-23999530',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>   
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
</head>   
<body>   
 <strong><?php echo $_smarty_tpl->getVariable('errorStr')->value;?>
</strong>
</body>  
</html>
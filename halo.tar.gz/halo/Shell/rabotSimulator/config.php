<?php
/**
 * 外挂模拟器配置
 */
define('RABOT_HOST', '127.0.0.1');         								  // host
define('RABOT_PORT', '3306');              								  // 端口号
define('RABOT_DEFAULT_URL', 'http://cn-i1.qjp.kunlun.com');              // 默认的请求地址
define('RABOT_DEFAULT_INTERVAL', 1000000);         						  // 默认的请求时间间隔

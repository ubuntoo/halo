<?php
namespace ctrl;

/**
 * GoodsOfficial 控制器类
 * 
 * @author wei.wang
 */
class GoodsOfficial extends CtrlBase
{
    /**
     * 主方法
     *
     * @return 
     */
    public function main()
    {
        return ;
    }
}
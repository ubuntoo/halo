<?php
namespace dao;

/**
 * 数据录入  数据库操作 类 
 * 
 * @author
 */
class DataEntry extends DaoBase
{
	
}
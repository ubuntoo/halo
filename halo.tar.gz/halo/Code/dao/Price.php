<?php
namespace dao;

/**
 * 价格  数据库操作 类 
 * 
 * @author
 */
class Test extends DaoBase
{
	
}
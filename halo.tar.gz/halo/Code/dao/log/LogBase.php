<?php
namespace dao;
/**
 * 日志层抽象基类
 * 
 * @author
 */
abstract class LogBase extends DaoBase 
{
    /**
     * 构造函数
     * 
     * @return void
     */
    public function __construct() 
    {
    }
}
<?php
namespace dao;

/**
 * 公用  数据库操作 类 
 * 
 * @author
 */
class Common extends DaoBase
{
}
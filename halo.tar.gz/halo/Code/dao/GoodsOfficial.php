<?php
namespace dao;

/**
 * GoodsOfficial 数据库类
 * 
 * @author wei.wang
 */
class GoodsOfficial extends DaoBase
{
    /**
     * 主方法
     *
     * @return 
     */
    public function main()
    {
        return ;
    }
}
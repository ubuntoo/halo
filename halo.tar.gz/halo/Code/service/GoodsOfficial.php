<?php
namespace service;

/**
 * GoodsOfficial 逻辑类
 * 
 * @author wei.wang
 */
class GoodsOfficial extends ServiceBase
{
    /**
     * 主方法
     *
     * @return 
     */
    public function main()
    {
        return ;
    }
}
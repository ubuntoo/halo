<?php
namespace service;

/**
 * 协议接口
 *
 * @author
 */
interface IProtocol {
    public function test($params);
}
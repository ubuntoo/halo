<?php
namespace service;

/**
 * 数据采集类
 * 
 * @author 
 */
class Collection
{
}